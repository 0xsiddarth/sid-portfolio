import Header from '@/components/header';
import Hero from '@/components/hero';
import Projects from '@/components/projects';
import Certifications from '@/components/certifications';
import Articles from '@/components/articles';
import Footer from '@/components/footer';
import AnimatedBackground from '@/components/animated-background';
import Resume from '@/components/resume';

export default function Home() {
  return (
    <div className="relative flex min-h-screen w-full flex-col overflow-x-hidden">
      <AnimatedBackground />
      <div className="relative z-10 flex flex-col">
        <Header />
        <main className="container mx-auto flex-grow px-4">
          <Hero />
          <div className="space-y-24 md:space-y-32">
            <Projects />
            <Resume />
            <Certifications />
            <Articles />
          </div>
        </main>
        <Footer />
      </div>
    </div>
  );
}
