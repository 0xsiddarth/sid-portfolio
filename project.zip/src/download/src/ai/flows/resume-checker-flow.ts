'use server';

/**
 * @fileOverview An AI agent for providing feedback on a resume based on a job description.
 *
 * - checkResume - A function that handles the resume check process.
 * - CheckResumeInput - The input type for the checkResume function.
 * - CheckResumeOutput - The return type for the checkResume function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const CheckResumeInputSchema = z.object({
  resumeDataUri: z
    .string()
    .describe(
      "The user's resume, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
  jobDescription: z
    .string()
    .describe('The job description to compare the resume against.'),
});

export type CheckResumeInput = z.infer<typeof CheckResumeInputSchema>;

const CheckResumeOutputSchema = z.object({
  feedback: z
    .string()
    .describe(
      'Constructive feedback for the resume, formatted as markdown.'
    ),
});

export type CheckResumeOutput = z.infer<typeof CheckResumeOutputSchema>;

export async function checkResume(
  input: CheckResumeInput
): Promise<CheckResumeOutput> {
  return checkResumeFlow(input);
}

const prompt = ai.definePrompt({
  name: 'checkResumePrompt',
  input: {schema: CheckResumeInputSchema},
  output: {schema: CheckResumeOutputSchema},
  prompt: `You are an expert career coach and hiring manager specializing in cybersecurity roles.

  Analyze the provided resume and compare it against the following job description.

  Job Description:
  ---
  {{jobDescription}}
  ---

  Resume:
  {{media url=resumeDataUri}}

  Provide detailed, constructive feedback on how to improve the resume to better match the job requirements.
  Focus on:
  - Highlighting relevant skills and experience.
  - Incorporating keywords from the job description.
  - Improving clarity, formatting, and overall presentation.
  - Suggesting specific changes or additions.

  Format your feedback using markdown for readability.
  `,
});

const checkResumeFlow = ai.defineFlow(
  {
    name: 'checkResumeFlow',
    inputSchema: CheckResumeInputSchema,
    outputSchema: CheckResumeOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
