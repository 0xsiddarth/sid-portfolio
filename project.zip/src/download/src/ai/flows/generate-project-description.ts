'use server';

/**
 * @fileOverview An AI agent for generating personalized project descriptions for cybersecurity students.
 *
 * - generateProjectDescription - A function that generates project descriptions.
 * - GenerateProjectDescriptionInput - The input type for the generateProjectDescription function.
 * - GenerateProjectDescriptionOutput - The return type for the generateProjectDescription function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateProjectDescriptionInputSchema = z.object({
  projectName: z.string().describe('The name of the project.'),
  projectType: z.string().describe('The type of project (e.g., penetration testing, malware analysis).'),
  techStack: z.string().describe('The technologies used in the project (e.g., Python, Nmap, Wireshark).'),
  projectDescription: z.string().describe('A detailed description of the project.'),
  personalizationPreferences: z.string().describe('Specific aspects to highlight or tailor the description to.'),
});

export type GenerateProjectDescriptionInput = z.infer<
  typeof GenerateProjectDescriptionInputSchema
>;

const GenerateProjectDescriptionOutputSchema = z.object({
  personalizedDescription: z.string().describe('The AI-generated personalized project description.'),
});

export type GenerateProjectDescriptionOutput = z.infer<
  typeof GenerateProjectDescriptionOutputSchema
>;

export async function generateProjectDescription(
  input: GenerateProjectDescriptionInput
): Promise<GenerateProjectDescriptionOutput> {
  return generateProjectDescriptionFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateProjectDescriptionPrompt',
  input: {schema: GenerateProjectDescriptionInputSchema},
  output: {schema: GenerateProjectDescriptionOutputSchema},
  prompt: `You are an AI expert in creating compelling and personalized project descriptions for cybersecurity students.

  Given the following information about a project, generate a personalized description that effectively showcases the student's skills and accomplishments.

  Project Name: {{projectName}}
  Project Type: {{projectType}}
  Tech Stack: {{techStack}}
  Project Description: {{projectDescription}}
  Personalization Preferences: {{personalizationPreferences}}

  Generate a description that is tailored to the student's preferences, highlighting the most important aspects of the project.
  `,
});

const generateProjectDescriptionFlow = ai.defineFlow(
  {
    name: 'generateProjectDescriptionFlow',
    inputSchema: GenerateProjectDescriptionInputSchema,
    outputSchema: GenerateProjectDescriptionOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
