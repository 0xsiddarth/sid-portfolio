import Link from 'next/link';
import { Award, ShieldAlert, BadgeCheck, Network } from 'lucide-react';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const certifications = [
  {
    name: 'Certified Ethical Hacker (CEH)',
    authority: 'EC-Council',
    link: '#',
    icon: <ShieldAlert className="h-8 w-8 text-accent" />,
  },
  {
    name: 'CompTIA Security+',
    authority: 'CompTIA',
    link: '#',
    icon: <BadgeCheck className="h-8 w-8 text-accent" />,
  },
  {
    name: 'Cisco Certified Network Associate (CCNA)',
    authority: 'Cisco',
    link: '#',
    icon: <Network className="h-8 w-8 text-accent" />,
  },
  {
    name: 'Cybersecurity Excellence Award',
    authority: 'National Cyber League',
    link: '#',
    icon: <Award className="h-8 w-8 text-accent" />,
  },
];

export default function Certifications() {
  return (
    <section id="certifications" className="py-16">
      <h2 className="text-center font-headline text-4xl font-bold mb-4">Certifications & Awards</h2>
      <p className="mb-12 text-center text-lg text-muted-foreground">
        My professional credentials and recognitions in the field.
      </p>
      <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
        {certifications.map((cert) => (
          <Card key={cert.name} className="bg-card/70 backdrop-blur-sm">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div className="flex items-center gap-4">
                {cert.icon}
                <CardTitle className="text-lg font-medium">{cert.name}</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">{cert.authority}</p>
              <Button asChild variant="outline" size="sm" className="mt-4">
                <Link href={cert.link}>Validate</Link>
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
}
