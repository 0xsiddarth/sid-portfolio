import Image from 'next/image';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const articles = [
  {
    title: 'Deconstructing the Anatomy of a Phishing Attack',
    description: 'A deep dive into the common techniques used by attackers in phishing campaigns and how to defend against them.',
    link: '#',
    image: 'https://placehold.co/600x400.png',
    dataAiHint: 'phishing security',
  },
  {
    title: 'Securing IoT Devices in a Smart Home Network',
    description: 'Practical steps and best practices for hardening your Internet of Things devices to prevent unauthorized access.',
    link: '#',
    image: 'https://placehold.co/600x400.png',
    dataAiHint: 'iot security',
  },
  {
    title: 'The Rise of Ransomware: Trends and Mitigation',
    description: 'Exploring the evolution of ransomware threats and strategies for prevention and recovery.',
    link: '#',
    image: 'https://placehold.co/600x400.png',
    dataAiHint: 'ransomware code',
  },
];

export default function Articles() {
  return (
    <section id="articles" className="py-16">
      <h2 className="text-center font-headline text-4xl font-bold mb-4">Writings & Posts</h2>
      <p className="mb-12 text-center text-lg text-muted-foreground">
        Sharing insights on cybersecurity trends and technologies.
      </p>
      <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
        {articles.map((article) => (
          <Card key={article.title} className="flex transform-gpu flex-col overflow-hidden transition-all duration-300 ease-out hover:shadow-primary/20 hover:shadow-lg hover:-translate-y-2">
            <CardHeader className="p-0">
              <Image src={article.image} alt={article.title} width={600} height={400} className="w-full object-cover" data-ai-hint={article.dataAiHint} />
            </CardHeader>
            <div className="flex flex-grow flex-col p-6">
              <CardTitle className="mb-2 text-xl">{article.title}</CardTitle>
              <CardDescription className="flex-grow">{article.description}</CardDescription>
              <CardFooter className="p-0 pt-6">
                <Button asChild variant="link" className="p-0">
                  <Link href={article.link}>
                    Read More <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </CardFooter>
            </div>
          </Card>
        ))}
      </div>
    </section>
  );
}
