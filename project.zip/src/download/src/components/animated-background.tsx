export default function AnimatedBackground() {
  return (
    <div className="fixed inset-0 -z-0 h-full w-full">
      <div className="absolute inset-0 h-full w-full bg-transparent bg-[linear-gradient(to_right,hsl(var(--border))_1px,transparent_1px),linear-gradient(to_bottom,hsl(var(--border))_1px,transparent_1px)] bg-[size:36px_36px] opacity-20"></div>
      <div className="absolute inset-0 h-full w-full bg-[radial-gradient(circle_800px_at_50%_200px,hsl(var(--primary)/.15),transparent)]"></div>
    </div>
  );
}
