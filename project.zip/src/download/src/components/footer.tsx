import Link from 'next/link';
import { Github, Linkedin, ShieldCheck } from 'lucide-react';

export default function Footer() {
  return (
    <footer id="contact" className="border-t border-border/50 bg-background/80 backdrop-blur-sm">
      <div className="container mx-auto flex flex-col items-center justify-between gap-4 px-4 py-8 md:flex-row">
        <Link href="/" className="flex items-center gap-2 text-lg font-bold text-primary">
          <ShieldCheck className="h-6 w-6" />
          <span>CyberEdge Portfolio</span>
        </Link>
        <div className="text-center text-sm text-muted-foreground">
          © {new Date().getFullYear()} Alex Doe. All Rights Reserved.
        </div>
        <div className="flex items-center gap-4">
          <a href="https://github.com" target="_blank" rel="noopener noreferrer" aria-label="GitHub Profile">
            <Github className="h-6 w-6 transition-colors hover:text-primary" />
          </a>
          <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn Profile">
            <Linkedin className="h-6 w-6 transition-colors hover:text-primary" />
          </a>
        </div>
      </div>
    </footer>
  );
}
