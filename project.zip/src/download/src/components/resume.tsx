import { Briefcase, GraduationCap, Download } from 'lucide-react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';

const experiences = [
  {
    role: 'Cybersecurity Analyst',
    company: 'SecureNet Solutions',
    period: 'Jan 2022 - Present',
    description: [
      'Monitored network traffic for suspicious activity and performed incident response.',
      'Conducted vulnerability assessments and penetration testing on web applications.',
      'Developed and implemented security policies and procedures.',
    ],
  },
  {
    role: 'IT Security Intern',
    company: 'DataCorp Inc.',
    period: 'May 2021 - Dec 2021',
    description: [
      'Assisted senior analysts with security audits and compliance checks.',
      'Managed and maintained security tools, including firewalls and IDS/IPS.',
      'Contributed to the creation of security awareness training materials.',
    ],
  },
];

const education = [
  {
    degree: 'Bachelor of Science in Cybersecurity',
    institution: 'University of Technology',
    period: '2018 - 2022',
    description: 'Graduated with honors. Coursework included Network Security, Ethical Hacking, Cryptography, and Digital Forensics.',
  },
];

export default function Resume() {
  return (
    <section id="resume" className="py-16">
      <div className="text-center">
        <h2 className="text-center font-headline text-4xl font-bold mb-4">Resume</h2>
        <p className="mb-8 text-center text-lg text-muted-foreground">
          A summary of my professional experience and education.
        </p>
        <Button asChild>
            <Link href="/alex-doe-resume.pdf" target="_blank">
                <Download className="mr-2 h-4 w-4" />
                Download CV
            </Link>
        </Button>
      </div>

      <div className="mt-16 grid grid-cols-1 gap-16 lg:grid-cols-2">
        <div>
          <h3 className="mb-8 flex items-center gap-4 text-2xl font-bold">
            <Briefcase className="h-8 w-8 text-primary" />
            Work Experience
          </h3>
          <div className="relative space-y-8 border-l-2 border-border/50 pl-8">
             <div className="absolute -left-[1.6px] top-1 h-full w-[2px] bg-primary/20"></div>
            {experiences.map((exp, index) => (
              <Card key={index} className="bg-card/70 backdrop-blur-sm transform-gpu transition-all duration-300 ease-out hover:shadow-primary/20 hover:shadow-lg hover:-translate-y-1">
                <div className="absolute -left-[38px] top-1 flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground">
                  <Briefcase className="h-5 w-5" />
                </div>
                <CardHeader>
                  <CardTitle>{exp.role}</CardTitle>
                  <CardDescription>
                    {exp.company} | {exp.period}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="list-disc space-y-2 pl-5 text-muted-foreground">
                    {exp.description.map((item, i) => (
                      <li key={i}>{item}</li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <div>
          <h3 className="mb-8 flex items-center gap-4 text-2xl font-bold">
            <GraduationCap className="h-8 w-8 text-primary" />
            Education
          </h3>
           <div className="relative space-y-8 border-l-2 border-border/50 pl-8">
            <div className="absolute -left-[1.6px] top-1 h-full w-[2px] bg-primary/20"></div>
            {education.map((edu, index) => (
              <Card key={index} className="bg-card/70 backdrop-blur-sm transform-gpu transition-all duration-300 ease-out hover:shadow-primary/20 hover:shadow-lg hover:-translate-y-1">
                 <div className="absolute -left-[38px] top-1 flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground">
                  <GraduationCap className="h-5 w-5" />
                </div>
                <CardHeader>
                  <CardTitle>{edu.degree}</CardTitle>
                  <CardDescription>
                    {edu.institution} | {edu.period}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{edu.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
