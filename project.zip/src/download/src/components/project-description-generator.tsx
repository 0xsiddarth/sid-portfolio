'use client';

import { useState } from 'react';
import { useForm, type SubmitHandler } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Copy, Loader2, Sparkles } from 'lucide-react';

import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { handleGenerateDescription } from '@/app/actions';
import { useToast } from '@/hooks/use-toast';

const formSchema = z.object({
  projectName: z.string().min(1, 'Project name is required.'),
  projectType: z.string().min(1, 'Project type is required.'),
  techStack: z.string().min(1, 'Tech stack is required.'),
  projectDescription: z.string().min(10, 'Please provide a more detailed description.').max(1000),
  personalizationPreferences: z.string().min(1, 'Personalization preferences are required.'),
});

type FormValues = z.infer<typeof formSchema>;

export default function ProjectDescriptionGenerator() {
  const [generatedDescription, setGeneratedDescription] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      projectName: '',
      projectType: '',
      techStack: '',
      projectDescription: '',
      personalizationPreferences: 'Make it sound professional for a job application.',
    },
  });

  const onSubmit: SubmitHandler<FormValues> = async (data) => {
    setIsLoading(true);
    setGeneratedDescription('');
    const result = await handleGenerateDescription(data);
    setIsLoading(false);

    if (result.success && result.data) {
      setGeneratedDescription(result.data.personalizedDescription);
    } else {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: result.error || 'Something went wrong.',
      });
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(generatedDescription);
    toast({
      title: 'Copied!',
      description: 'The description has been copied to your clipboard.',
    });
  };

  return (
    <Card className="mx-auto max-w-4xl border-primary/20 bg-card/50 shadow-lg shadow-primary/10">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-2xl">
          <Sparkles className="h-6 w-6 text-primary" />
          <span>AI Description Generator</span>
        </CardTitle>
        <CardDescription>
          Fill in your project details and let our AI craft a compelling, personalized description for you.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
              <FormField
                control={form.control}
                name="projectName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Project Name</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., SecureAuth System" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="projectType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Project Type</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Penetration Testing" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <FormField
              control={form.control}
              name="techStack"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Technologies Used</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., Python, Nmap, Wireshark" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="projectDescription"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Current Project Description</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Describe your project..." {...field} rows={5} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="personalizationPreferences"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Personalization Preferences</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., Emphasize teamwork skills" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button type="submit" disabled={isLoading} className="w-full md:w-auto">
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Generating...
                </>
              ) : (
                'Generate Description'
              )}
            </Button>
          </form>
        </Form>
        {(isLoading || generatedDescription) && (
          <div className="mt-8 rounded-lg border bg-muted/50 p-4">
            <h4 className="mb-2 font-semibold">Generated Description:</h4>
            {isLoading && (
              <div className="space-y-2">
                <div className="h-4 w-full animate-pulse rounded bg-muted-foreground/20"></div>
                <div className="h-4 w-5/6 animate-pulse rounded bg-muted-foreground/20"></div>
                <div className="h-4 w-full animate-pulse rounded bg-muted-foreground/20"></div>
              </div>
            )}
            {generatedDescription && (
              <div className="relative">
                <Textarea readOnly value={generatedDescription} rows={6} className="bg-background pr-10" />
                <Button variant="ghost" size="icon" className="absolute right-2 top-2 h-7 w-7" onClick={handleCopy}>
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
