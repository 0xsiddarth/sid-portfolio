import Link from 'next/link';
import { Button } from '@/components/ui/button';

export default function Hero() {
  return (
    <section id="hero" className="flex min-h-[calc(100vh-5rem)] flex-col items-center justify-center py-20 text-center md:py-32">
      <h1 className="font-headline text-5xl font-bold tracking-tighter md:text-7xl lg:text-8xl">
        Alex Doe
      </h1>
      <div className="mt-4 flex items-center justify-center">
        <p className="max-w-2xl text-xl text-muted-foreground md:text-2xl">
          Cybersecurity Professional & Ethical Hacking Enthusiast
        </p>
      </div>
      <p className="mt-6 max-w-xl text-lg text-muted-foreground">
        Passionate about building secure digital environments and defending against cyber threats through innovative solutions.
      </p>
      <div className="mt-8 flex gap-4">
        <Button asChild size="lg">
          <Link href="#projects">View My Work</Link>
        </Button>
        <Button asChild size="lg" variant="outline">
          <Link href="#contact">Get In Touch</Link>
        </Button>
      </div>
    </section>
  );
}
