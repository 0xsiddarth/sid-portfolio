import Link from 'next/link';
import { ExternalLink, Github } from 'lucide-react';

import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';

const projects = [
  {
    title: 'Vulnerability Scanner',
    description: 'A Python-based tool that scans web applications for common vulnerabilities like SQL injection, XSS, and insecure configurations.',
    techStack: ['Python', 'Nmap', 'OWASP ZAP API'],
    githubLink: '#',
    liveLink: null,
  },
  {
    title: 'Honeypot System',
    description: 'Developed and deployed a low-interaction honeypot to capture and analyze automated attack patterns on a network.',
    techStack: ['Docker', 'Python (Flask)', 'ELK Stack'],
    githubLink: '#',
    liveLink: '#',
  },
  {
    title: 'Encrypted Chat Application',
    description: 'A secure messaging application using end-to-end encryption to ensure data privacy and confidentiality during communication.',
    techStack: ['Node.js', 'React', 'Cryptography.js'],
    githubLink: '#',
    liveLink: '#',
  },
  {
    title: 'Malware Analysis Sandbox',
    description: 'A controlled environment for safely executing and analyzing malware samples to understand their behavior and impact.',
    techStack: ['Cuckoo Sandbox', 'Volatility', 'YARA'],
    githubLink: '#',
    liveLink: null,
  },
];

export default function Projects() {
  return (
    <section id="projects" className="py-16">
      <h2 className="text-center font-headline text-4xl font-bold mb-4">Projects Showcase</h2>
      <p className="mb-12 text-center text-lg text-muted-foreground">
        A selection of my work in cybersecurity and software development.
      </p>
      <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
        {projects.map((project) => (
          <Card key={project.title} className="flex flex-col bg-card/70 backdrop-blur-sm transition-all duration-300 hover:border-primary/50 hover:shadow-lg hover:shadow-primary/10">
            <CardHeader>
              <CardTitle>{project.title}</CardTitle>
              <CardDescription>{project.description}</CardDescription>
            </CardHeader>
            <CardContent className="flex-grow">
              <div className="flex flex-wrap gap-2">
                {project.techStack.map((tech) => (
                  <Badge key={tech} variant="secondary">
                    {tech}
                  </Badge>
                ))}
              </div>
            </CardContent>
            <CardFooter className="flex justify-end gap-4">
              <Button asChild variant="outline">
                <Link href={project.githubLink}>
                  <Github className="mr-2 h-4 w-4" />
                  GitHub
                </Link>
              </Button>
              {project.liveLink && (
                <Button asChild>
                  <Link href={project.liveLink}>
                    <ExternalLink className="mr-2 h-4 w-4" />
                    Live Demo
                  </Link>
                </Button>
              )}
            </CardFooter>
          </Card>
        ))}
      </div>
    </section>
  );
}
