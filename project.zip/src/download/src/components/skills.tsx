import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Shield, Network, Code, Terminal, Database, Lock, Server } from 'lucide-react';

const skills = [
  { name: 'Penetration Testing', level: 90, icon: <Shield className="h-6 w-6 text-primary" /> },
  { name: 'Network Security', level: 85, icon: <Network className="h-6 w-6 text-primary" /> },
  { name: 'Python & Scripting', level: 80, icon: <Code className="h-6 w-6 text-primary" /> },
  { name: 'Metasploit Framework', level: 75, icon: <Terminal className="h-6 w-6 text-primary" /> },
  { name: 'Cryptography', level: 70, icon: <Lock className="h-6 w-6 text-primary" /> },
  { name: 'Linux/Unix Systems', level: 95, icon: <Server className="h-6 w-6 text-primary" /> },
];

export default function Skills() {
  return (
    <section id="skills" className="py-16">
      <h2 className="text-center font-headline text-4xl font-bold mb-4">Technical Prowess</h2>
      <p className="mb-12 text-center text-lg text-muted-foreground">
        My expertise across various cybersecurity domains and technologies.
      </p>
      <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
        {skills.map((skill) => (
          <Card key={skill.name} className="bg-card/70 backdrop-blur-sm">
            <CardHeader>
              <div className="flex items-center gap-4">
                {skill.icon}
                <CardTitle>{skill.name}</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <Progress value={skill.level} className="h-2" />
              <p className="mt-2 text-sm text-muted-foreground">{skill.level}% Proficiency</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
}
