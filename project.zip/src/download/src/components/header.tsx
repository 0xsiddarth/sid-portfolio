import Link from 'next/link';
import { Github, Linkedin, ShieldCheck } from 'lucide-react';

export default function Header() {
  const navLinks = [
    { href: '#projects', label: 'Projects' },
    { href: '#resume', label: 'Resume' },
    { href: '#certifications', label: 'Certs' },
    { href: '#articles', label: 'Articles' },
  ];

  return (
    <header className="fixed left-0 right-0 top-0 z-50 bg-background/80 backdrop-blur-sm">
      <div className="container mx-auto flex h-20 items-center justify-between px-4">
        <Link href="/" className="flex items-center gap-2 text-xl font-bold text-primary transition-transform hover:scale-105">
          <ShieldCheck className="h-7 w-7" />
          <span className="hidden sm:inline">CyberEdge</span>
        </Link>
        <nav className="hidden items-center rounded-full border bg-card p-1 text-sm md:flex">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="rounded-full px-4 py-1.5 font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
            >
              {link.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-4">
          <a href="https://github.com" target="_blank" rel="noopener noreferrer" aria-label="GitHub Profile">
            <Github className="h-6 w-6 transition-colors hover:text-primary" />
          </a>
          <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn Profile">
            <Linkedin className="h-6 w-6 transition-colors hover:text-primary" />
          </a>
        </div>
      </div>
    </header>
  );
}
