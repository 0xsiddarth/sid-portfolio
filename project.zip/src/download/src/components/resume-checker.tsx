'use client';

import { useState } from 'react';
import { useForm, type SubmitHandler } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Copy, Loader2, Sparkles, FileCheck2 } from 'lucide-react';

import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { handleResumeCheck } from '@/app/actions';
import { useToast } from '@/hooks/use-toast';

// To support file uploads
const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB
const ACCEPTED_FILE_TYPES = ["application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "text/plain"];

const formSchema = z.object({
  jobDescription: z.string().min(20, 'Please provide a more detailed job description.').max(5000),
  resumeFile: (typeof window === 'undefined' ? z.any() : z.instanceof(FileList))
    .refine((files) => files?.length === 1, 'Resume file is required.')
    .refine((files) => files?.[0]?.size <= MAX_FILE_SIZE, `Max file size is 5MB.`)
    .refine(
      (files) => ACCEPTED_FILE_TYPES.includes(files?.[0]?.type),
      ".pdf, .docx, and .txt files are accepted."
    ),
});

type FormValues = z.infer<typeof formSchema>;

export default function ResumeChecker() {
  const [feedback, setFeedback] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      jobDescription: '',
      resumeFile: undefined,
    },
  });

  const onSubmit: SubmitHandler<FormValues> = async (data) => {
    setIsLoading(true);
    setFeedback('');

    const file = data.resumeFile[0];
    const reader = new FileReader();

    reader.onloadend = async () => {
      const resumeDataUri = reader.result as string;
      const result = await handleResumeCheck({
        jobDescription: data.jobDescription,
        resumeDataUri,
      });

      setIsLoading(false);
      if (result.success && result.data) {
        setFeedback(result.data.feedback);
      } else {
        toast({
          variant: 'destructive',
          title: 'Error',
          description: result.error || 'Something went wrong.',
        });
      }
    };
    
    reader.onerror = () => {
      setIsLoading(false);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Failed to read the resume file.',
      });
    };

    reader.readAsDataURL(file);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(feedback);
    toast({
      title: 'Copied!',
      description: 'The feedback has been copied to your clipboard.',
    });
  };

  return (
    <Card className="mx-auto max-w-4xl border-primary/20 bg-card/50 shadow-lg shadow-primary/10">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-2xl">
          <FileCheck2 className="h-6 w-6 text-primary" />
          <span>AI Resume Checker</span>
        </CardTitle>
        <CardDescription>
          Upload your resume and paste a job description to get AI-powered feedback.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="resumeFile"
              render={({ field: { onChange, onBlur, name, ref } }) => (
                <FormItem>
                  <FormLabel>Your Resume (.pdf, .docx, .txt)</FormLabel>
                  <FormControl>
                    <Input 
                      type="file" 
                      accept="application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document,text/plain"
                      onChange={(e) => onChange(e.target.files)}
                      onBlur={onBlur}
                      name={name}
                      ref={ref}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="jobDescription"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Job Description</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Paste the job description here..." {...field} rows={8} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <Button type="submit" disabled={isLoading} className="w-full md:w-auto">
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Sparkles className="mr-2 h-4 w-4" />
                  Check Resume
                </>
              )}
            </Button>
          </form>
        </Form>
        {(isLoading || feedback) && (
          <div className="mt-8 rounded-lg border bg-muted/50 p-4">
            <h4 className="mb-2 font-semibold">AI Feedback:</h4>
            {isLoading && (
              <div className="space-y-2">
                <div className="h-4 w-full animate-pulse rounded bg-muted-foreground/20"></div>
                <div className="h-4 w-5/6 animate-pulse rounded bg-muted-foreground/20"></div>
                <div className="h-4 w-full animate-pulse rounded bg-muted-foreground/20"></div>
                <div className="h-4 w-3/4 animate-pulse rounded bg-muted-foreground/20"></div>
              </div>
            )}
            {feedback && (
              <div className="relative">
                 <Textarea readOnly value={feedback} rows={15} className="bg-background pr-10" />
                <Button variant="ghost" size="icon" className="absolute right-2 top-2 h-7 w-7" onClick={handleCopy}>
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
